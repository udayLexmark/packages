var pairs =
{
"integration":{"server":1}
,"server":{"administrator":1}
}
;Search.control.loadWordPairs(pairs);
