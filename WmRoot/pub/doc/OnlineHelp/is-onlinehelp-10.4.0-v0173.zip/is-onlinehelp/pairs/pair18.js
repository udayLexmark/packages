var pairs =
{
"logs":{"menu":1}
}
;Search.control.loadWordPairs(pairs);
