var pairs =
{
"settings":{"menu":1}
}
;Search.control.loadWordPairs(pairs);
